import { BrowserRouter, Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import { useEffect } from 'react';
import { AuthProvider, useAuth } from '@/lib/auth';
import { ToastProvider } from '@/components/Toast';
import { ArkonLogo } from '@/components/ArkonLogo';
import { LoginPage } from '@/pages/LoginPage';
import { DashboardLayout } from '@/components/DashboardLayout';
import { DashboardPage } from '@/pages/DashboardPage';
import { PackagesPage } from '@/pages/PackagesPage';
import { ContractsPage } from '@/pages/ContractsPage';
import { NewContractPage } from '@/pages/NewContractPage';
import { ContractDetailPage } from '@/pages/ContractDetailPage';
import { ClientsPage } from '@/pages/ClientsPage';
import { ClientProfilePage } from '@/pages/ClientProfilePage';
import { EmployeesPage } from '@/pages/EmployeesPage';
import { SchedulePage } from '@/pages/SchedulePage';
import { NotificationsPage } from '@/pages/NotificationsPage';
import { SettingsPage } from '@/pages/SettingsPage';
import { VisitsPage } from '@/pages/VisitsPage';
import { CalendarPage } from '@/pages/CalendarPage';
import { ReportsPage } from '@/pages/ReportsPage';
import { AuditPage } from '@/pages/AuditPage';
import { NewClientPage } from '@/pages/NewClientPage';
import { InvoicesPage } from '@/pages/InvoicesPage';
import { InventoryPage } from '@/pages/InventoryPage';
import { OpportunitiesPage } from '@/pages/OpportunitiesPage';
import { FinancePage } from '@/pages/FinancePage';
import { SalesPage } from '@/pages/SalesPage';
import { ArkonOSPage } from '@/pages/ArkonOSPage';
import { HomePage } from '@/pages/HomePage';
import { WorkerApp, WorkerHome, WorkerVisits, WorkerQr, WorkerProfile } from '@/pages/WorkerApp';
import { ClientApp, ClientHome, ClientVisits, ClientInvoices, ClientSupport, ClientProfile } from '@/pages/ClientApp';
import { getDefaultRoute } from '@/lib/navigation';

function LoadingScreen() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-50">
      <div className="flex flex-col items-center gap-4">
        <ArkonLogo size={56} />
        <div className="h-1 w-32 overflow-hidden rounded-full bg-slate-200">
          <div className="h-full w-1/2 animate-shimmer rounded-full bg-brand-500" style={{ backgroundSize: '200% 100%' }} />
        </div>
      </div>
    </div>
  );
}

function AccessDenied() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-slate-50 px-4 text-center" dir="rtl">
      <div className="flex h-16 w-16 items-center justify-center rounded-full bg-danger-50">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-danger-500">
          <circle cx="12" cy="12" r="10" />
          <line x1="4.93" y1="4.93" x2="19.07" y2="19.07" />
        </svg>
      </div>
      <h1 className="font-display text-xl font-700 text-slate-900">لا تملك صلاحية الوصول</h1>
      <p className="text-sm text-slate-500">هذه الصفحة غير متاحة لدورك الوظيفي.</p>
    </div>
  );
}

function ProtectedRoute({ children, permission }: { children: React.ReactNode; permission?: string }) {
  const { session, loading, hasPermission } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && session && permission && !hasPermission(permission)) {
      const defaultRoute = getDefaultRoute(session.permissions ?? [], session.kind);
      navigate(defaultRoute, { replace: true });
    }
  }, [session, loading, permission, hasPermission, navigate]);

  if (loading) return <LoadingScreen />;
  if (!session) return <Navigate to="/login" replace />;
  if (permission && !hasPermission(permission)) return <AccessDenied />;
  return <>{children}</>;
}

function PublicOnlyRoute({ children }: { children: React.ReactNode }) {
  const { session, loading } = useAuth();
  if (loading) return null;
  if (session) {
    const defaultRoute = getDefaultRoute(session.permissions ?? [], session.kind);
    return <Navigate to={defaultRoute} replace />;
  }
  return <>{children}</>;
}

export default function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/os" element={<ArkonOSPage />} />
            <Route path="/login" element={<PublicOnlyRoute><LoginPage /></PublicOnlyRoute>} />

            {/* Staff routes */}
            <Route element={<ProtectedRoute><DashboardLayout /></ProtectedRoute>}>
              <Route path="/dashboard" element={<ProtectedRoute permission="dashboard"><DashboardPage /></ProtectedRoute>} />
              <Route path="/packages" element={<ProtectedRoute permission="packages"><PackagesPage /></ProtectedRoute>} />
              <Route path="/contracts" element={<ProtectedRoute permission="contracts"><ContractsPage /></ProtectedRoute>} />
              <Route path="/contracts/new" element={<ProtectedRoute permission="contracts"><NewContractPage /></ProtectedRoute>} />
              <Route path="/contracts/:id" element={<ProtectedRoute permission="contracts"><ContractDetailPage /></ProtectedRoute>} />
              <Route path="/clients" element={<ProtectedRoute permission="clients"><ClientsPage /></ProtectedRoute>} />
              <Route path="/clients/new" element={<ProtectedRoute permission="clients"><NewClientPage /></ProtectedRoute>} />
              <Route path="/clients/:id" element={<ProtectedRoute permission="clients"><ClientProfilePage /></ProtectedRoute>} />
              <Route path="/employees" element={<ProtectedRoute permission="employees"><EmployeesPage /></ProtectedRoute>} />
              <Route path="/visits" element={<ProtectedRoute permission="visits"><VisitsPage /></ProtectedRoute>} />
              <Route path="/schedule" element={<ProtectedRoute permission="schedule"><SchedulePage /></ProtectedRoute>} />
              <Route path="/calendar" element={<ProtectedRoute permission="calendar"><CalendarPage /></ProtectedRoute>} />
              <Route path="/reports" element={<ProtectedRoute permission="reports"><ReportsPage /></ProtectedRoute>} />
              <Route path="/audit" element={<ProtectedRoute permission="audit"><AuditPage /></ProtectedRoute>} />
              <Route path="/notifications" element={<ProtectedRoute permission="notifications"><NotificationsPage /></ProtectedRoute>} />
              <Route path="/invoices" element={<ProtectedRoute permission="invoices"><InvoicesPage /></ProtectedRoute>} />
              <Route path="/inventory" element={<ProtectedRoute permission="inventory"><InventoryPage /></ProtectedRoute>} />
              <Route path="/opportunities" element={<ProtectedRoute permission="opportunities"><OpportunitiesPage /></ProtectedRoute>} />
              <Route path="/finance" element={<ProtectedRoute permission="finance"><FinancePage /></ProtectedRoute>} />
              <Route path="/sales" element={<ProtectedRoute permission="sales"><SalesPage /></ProtectedRoute>} />
              <Route path="/settings" element={<ProtectedRoute permission="settings"><SettingsPage /></ProtectedRoute>} />
            </Route>

            {/* Worker mobile app */}
            <Route element={<ProtectedRoute permission="worker_home"><WorkerApp /></ProtectedRoute>}>
              <Route path="/worker" element={<ProtectedRoute permission="worker_home"><WorkerHome /></ProtectedRoute>} />
              <Route path="/worker/visits" element={<ProtectedRoute permission="worker_visits"><WorkerVisits /></ProtectedRoute>} />
              <Route path="/worker/qr" element={<ProtectedRoute permission="worker_qr"><WorkerQr /></ProtectedRoute>} />
              <Route path="/worker/profile" element={<ProtectedRoute permission="worker_profile"><WorkerProfile /></ProtectedRoute>} />
            </Route>

            {/* Client mobile app */}
            <Route element={<ProtectedRoute permission="client_home"><ClientApp /></ProtectedRoute>}>
              <Route path="/client" element={<ProtectedRoute permission="client_home"><ClientHome /></ProtectedRoute>} />
              <Route path="/client/visits" element={<ProtectedRoute permission="client_visits"><ClientVisits /></ProtectedRoute>} />
              <Route path="/client/invoices" element={<ProtectedRoute permission="client_invoices"><ClientInvoices /></ProtectedRoute>} />
              <Route path="/client/support" element={<ProtectedRoute permission="client_support"><ClientSupport /></ProtectedRoute>} />
              <Route path="/client/profile" element={<ProtectedRoute permission="client_profile"><ClientProfile /></ProtectedRoute>} />
            </Route>

            <Route path="*" element={<Navigate to="/login" replace />} />
          </Routes>
        </BrowserRouter>
      </ToastProvider>
    </AuthProvider>
  );
}
