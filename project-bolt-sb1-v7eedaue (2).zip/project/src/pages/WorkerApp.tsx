import { useState, useEffect, useRef, useCallback } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import {
  Home, ClipboardCheck, QrCode, UserCircle, Phone, MapPin,
  Clock, CheckCircle2, Play, Square, LogOut, Camera, X, AlertCircle,
  Navigation, Star,
} from 'lucide-react';
import { ArkonLogo } from '@/components/ArkonLogo';
import { useAuth } from '@/lib/auth';
import { useToast } from '@/components/Toast';
import { supabase } from '@/lib/supabase';
import { visitService } from '@/services/visitService';
import { qrService } from '@/services/qrService';
import { PageLoader, EmptyState } from '@/components/Feedback';
import { formatDate, formatTime, cn } from '@/lib/utils';
import { VISIT_STATUS_LABELS } from '@/lib/locale';
import type { VisitWithRelations } from '@/types';

/* ===== Helpers ===== */

function getClientName(v: VisitWithRelations): string {
  return v.contract?.client?.full_name ?? v.client?.full_name ?? 'عميل';
}
function getClientPhone(v: VisitWithRelations): string {
  return v.contract?.client?.phone_number ?? v.client?.phone_number ?? '';
}
function getClientAddress(v: VisitWithRelations): string {
  return v.contract?.client?.address ?? v.client?.address ?? '—';
}
function getPackageName(v: VisitWithRelations): string {
  return v.contract?.package?.name ?? v.package?.name ?? '—';
}

function statusBadgeClass(status: string): string {
  switch (status) {
    case 'completed': return 'bg-success-50 text-success-700';
    case 'started': return 'bg-warning-50 text-warning-700';
    case 'cancelled': return 'bg-danger-50 text-danger-700';
    default: return 'bg-brand-50 text-brand-700';
  }
}

function isToday(dateStr: string): boolean {
  const d = new Date(dateStr);
  const today = new Date();
  return d.toDateString() === today.toDateString();
}

/* ===== QrScanner ===== */

function QrScanner({ onScan }: { onScan: (code: string) => void }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [manualCode, setManualCode] = useState('');

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
  }, []);

  useEffect(() => {
    let cancelled = false;

    async function start() {
      if (!('BarcodeDetector' in window)) {
        setError('المتصفح لا يدعم مسح QR. أدخل الرمز يدوياً بالأسفل.');
        return;
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' },
        });
        if (cancelled) { stream.getTracks().forEach((t) => t.stop()); return; }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
        }

        const detector = new (window as any).BarcodeDetector({
          formats: ['qr_code', 'code_128', 'code_39'],
        });

        const tick = async () => {
          if (cancelled || !videoRef.current) return;
          try {
            const codes = await detector.detect(videoRef.current);
            if (codes.length > 0) {
              const value = codes[0].rawValue as string;
              onScan(value);
              stopCamera();
              return;
            }
          } catch { /* ignore frame errors */ }
          requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
      } catch {
        if (!cancelled) setError('تعذر الوصول إلى الكاميرا. أدخل الرمز يدوياً.');
      }
    }
    start();
    return () => { cancelled = true; stopCamera(); };
  }, [onScan, stopCamera]);

  return (
    <div className="flex flex-col items-center gap-4">
      {error ? (
        <div className="flex items-center gap-2 rounded-lg bg-warning-50 px-4 py-3 text-sm text-warning-700">
          <AlertCircle size={18} /> {error}
        </div>
      ) : (
        <div className="relative aspect-square w-full max-w-xs overflow-hidden rounded-2xl border-2 border-brand-200 bg-slate-900">
          <video ref={videoRef} className="h-full w-full object-cover" playsInline muted />
          <div className="pointer-events-none absolute inset-0">
            <div className="absolute left-1/2 top-1/2 h-48 w-48 -translate-x-1/2 -translate-y-1/2 rounded-xl border-2 border-white/70" />
          </div>
        </div>
      )}
      <div className="flex w-full items-center gap-2">
        <input
          className="input flex-1"
          placeholder="أدخل رمز QR يدوياً"
          value={manualCode}
          onChange={(e) => setManualCode(e.target.value)}
          dir="ltr"
        />
        <button
          className="btn-primary shrink-0"
          onClick={() => { if (manualCode.trim()) onScan(manualCode.trim()); }}
          disabled={!manualCode.trim()}
        >
          تأكيد
        </button>
      </div>
    </div>
  );
}

/* ===== Visit Detail Modal ===== */

function VisitDetailModal({ visit, onClose }: { visit: VisitWithRelations; onClose: () => void }) {
  const { add } = useToast();
  const [scanning, setScanning] = useState(false);
  const [notes, setNotes] = useState(visit.notes ?? '');

  const handleScan = async (code: string) => {
    try {
      const result = await qrService.validate(code);
      if (!result.valid) {
        add('رمز QR غير صالح', 'error');
        return;
      }
      const clientId = visit.contract?.client?.id ?? visit.client?.id;
      if (result.clientId !== clientId) {
        add('هذا الرمز لا ينتمي لزيارة هذا العميل', 'error');
        return;
      }
      if (visit.status === 'scheduled') {
        await visitService.startVisit(visit.id);
        add('تم بدء الزيارة بنجاح', 'success');
      } else if (visit.status === 'started') {
        await visitService.finishVisit(visit.id);
        add('تم إنهاء الزيارة بنجاح', 'success');
      }
      setScanning(false);
      onClose();
    } catch (err) {
      add((err as Error).message, 'error');
    }
  };

  const phone = getClientPhone(visit);
  const address = getClientAddress(visit);

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-900/50 backdrop-blur-sm sm:items-center" dir="rtl">
      <div className="max-h-[90vh] w-full max-w-md overflow-y-auto rounded-t-2xl bg-white p-5 shadow-xl sm:rounded-2xl">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-lg font-700 text-slate-900">تفاصيل الزيارة</h2>
          <button onClick={onClose} className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100"><X size={20} /></button>
        </div>

        <div className="space-y-3">
          <div className="rounded-xl bg-slate-50 p-4">
            <p className="text-xs text-slate-400">العميل</p>
            <p className="font-600 text-slate-900">{getClientName(visit)}</p>
            <p className="mt-1 text-xs text-slate-400">الباقة</p>
            <p className="text-sm text-slate-700">{getPackageName(visit)}</p>
          </div>

          <div className="space-y-2 text-sm">
            <div className="flex items-center gap-2 text-slate-600"><MapPin size={16} className="text-slate-400" /> {address}</div>
            <div className="flex items-center gap-2 text-slate-600"><Clock size={16} className="text-slate-400" /> {formatDate(visit.scheduled_date)} {visit.scheduled_start_time ? `• ${formatTime(visit.scheduled_start_time)}` : ''}</div>
            <div className="flex items-center gap-2">
              <span className={cn('rounded-full px-2.5 py-0.5 text-xs font-600', statusBadgeClass(visit.status))}>
                {VISIT_STATUS_LABELS[visit.status] ?? visit.status}
              </span>
            </div>
          </div>

          {visit.notes && (
            <div className="rounded-lg border border-slate-200 p-3 text-sm text-slate-600">
              <p className="mb-1 text-xs font-600 text-slate-400">ملاحظات</p>
              {visit.notes}
            </div>
          )}

          {scanning ? (
            <div className="rounded-xl border border-brand-200 p-4">
              <QrScanner onScan={handleScan} />
              <button onClick={() => setScanning(false)} className="mt-3 w-full text-center text-sm text-slate-500">إلغاء</button>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2">
              {(visit.status === 'scheduled' || visit.status === 'started') && (
                <button
                  onClick={() => setScanning(true)}
                  className={cn('flex items-center justify-center gap-2 rounded-lg py-2.5 text-sm font-600', visit.status === 'scheduled' ? 'bg-brand-600 text-white' : 'bg-success-600 text-white')}
                >
                  {visit.status === 'scheduled' ? <><Play size={16} /> بدء الزيارة</> : <><Square size={16} /> إنهاء</>}
                </button>
              )}
              {phone && (
                <a href={`tel:${phone}`} className="flex items-center justify-center gap-2 rounded-lg bg-slate-100 py-2.5 text-sm font-600 text-slate-700">
                  <Phone size={16} /> اتصال
                </a>
              )}
              {address && address !== '—' && (
                <a
                  href={`https://maps.google.com/?q=${encodeURIComponent(address)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 rounded-lg bg-slate-100 py-2.5 text-sm font-600 text-slate-700"
                >
                  <Navigation size={16} /> انتقال
                </a>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ===== WorkerApp Layout ===== */

export function WorkerApp() {
  const { session } = useAuth();
  const workerName = session?.profile?.employee?.full_name ?? session?.profile?.display_name ?? 'الموظف';

  return (
    <div className="flex min-h-screen flex-col bg-slate-50" dir="rtl">
      <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-slate-200/60 bg-white/95 px-4 backdrop-blur">
        <ArkonLogo size={28} withWordmark variant="compact" />
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-100 text-sm font-600 text-brand-700">
            {workerName.charAt(0)}
          </div>
        </div>
      </header>

      <main className="mx-auto w-full max-w-md flex-1 pb-20">
        <Outlet />
      </main>

      <nav className="fixed inset-x-0 bottom-0 z-30 mx-auto flex max-w-md items-center justify-around border-t border-slate-200/60 bg-white/95 px-2 py-2 backdrop-blur">
        <NavLink to="/worker" end className={({ isActive }) => cn('flex flex-col items-center gap-0.5 px-3 py-1.5 text-xs font-500 transition', isActive ? 'text-brand-700' : 'text-slate-400')}>
          <Home size={22} /> الرئيسية
        </NavLink>
        <NavLink to="/worker/visits" className={({ isActive }) => cn('flex flex-col items-center gap-0.5 px-3 py-1.5 text-xs font-500 transition', isActive ? 'text-brand-700' : 'text-slate-400')}>
          <ClipboardCheck size={22} /> الزيارات
        </NavLink>
        <NavLink to="/worker/qr" className={({ isActive }) => cn('flex flex-col items-center gap-0.5 px-3 py-1.5 text-xs font-500 transition', isActive ? 'text-brand-700' : 'text-slate-400')}>
          <QrCode size={22} /> مسح
        </NavLink>
        <NavLink to="/worker/profile" className={({ isActive }) => cn('flex flex-col items-center gap-0.5 px-3 py-1.5 text-xs font-500 transition', isActive ? 'text-brand-700' : 'text-slate-400')}>
          <UserCircle size={22} /> الملف
        </NavLink>
      </nav>
    </div>
  );
}

/* ===== Worker Home ===== */

export function WorkerHome() {
  const { session } = useAuth();
  const [visits, setVisits] = useState<VisitWithRelations[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<VisitWithRelations | null>(null);

  const workerName = session?.profile?.employee?.full_name ?? session?.profile?.display_name ?? 'الموظف';
  const employeeId = session?.profile?.employee_id;

  useEffect(() => {
    if (!employeeId) { setLoading(false); return; }
    (async () => {
      try {
        const all = await visitService.getByEmployee(employeeId);
        setVisits(all.filter((v) => isToday(v.scheduled_date)));
      } catch { /* ignore */ } finally { setLoading(false); }
    })();
  }, [employeeId]);

  if (loading) return <PageLoader label="جاري التحميل..." />;
  if (!employeeId) return <EmptyState title="لا يوجد ملف موظف" description="لم يتم العثور على ملف الموظف المرتبط بحسابك." />;

  const completed = visits.filter((v) => v.status === 'completed').length;
  const remaining = visits.filter((v) => v.status === 'scheduled' || v.status === 'started').length;

  return (
    <div className="space-y-4 p-4" dir="rtl">
      <div>
        <h1 className="font-display text-xl font-700 text-slate-900">مرحباً، {workerName}</h1>
        <p className="text-sm text-slate-500">زياراتك لليوم</p>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="card p-3 text-center">
          <p className="text-2xl font-700 text-slate-900">{visits.length}</p>
          <p className="text-xs text-slate-500">الزيارات</p>
        </div>
        <div className="card p-3 text-center">
          <p className="text-2xl font-700 text-success-600">{completed}</p>
          <p className="text-xs text-slate-500">مكتملة</p>
        </div>
        <div className="card p-3 text-center">
          <p className="text-2xl font-700 text-warning-600">{remaining}</p>
          <p className="text-xs text-slate-500">المتبقية</p>
        </div>
      </div>

      <div className="space-y-2">
        {visits.length === 0 ? (
          <EmptyState icon={<CheckCircle2 size={32} className="text-slate-300" />} title="لا زيارات اليوم" description="لا توجد زيارات مجدولة لهذا اليوم." />
        ) : (
          visits.map((v) => (
            <button key={v.id} onClick={() => setSelected(v)} className="card flex w-full items-center gap-3 p-4 text-right transition hover:shadow-glow">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-brand-50">
                <ClipboardCheck size={20} className="text-brand-600" />
              </div>
              <div className="flex-1">
                <p className="font-600 text-slate-900">{getClientName(v)}</p>
                <p className="text-xs text-slate-500">{formatTime(v.scheduled_start_time ?? '')} • {getClientAddress(v)}</p>
              </div>
              <span className={cn('rounded-full px-2.5 py-0.5 text-xs font-600', statusBadgeClass(v.status))}>
                {VISIT_STATUS_LABELS[v.status] ?? v.status}
              </span>
            </button>
          ))
        )}
      </div>

      {selected && <VisitDetailModal visit={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}

/* ===== Worker Visits ===== */

export function WorkerVisits() {
  const { session } = useAuth();
  const [visits, setVisits] = useState<VisitWithRelations[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<VisitWithRelations | null>(null);
  const employeeId = session?.profile?.employee_id;

  useEffect(() => {
    if (!employeeId) { setLoading(false); return; }
    (async () => {
      try { setVisits(await visitService.getByEmployee(employeeId)); }
      catch { /* ignore */ } finally { setLoading(false); }
    })();
  }, [employeeId]);

  if (loading) return <PageLoader label="جاري التحميل..." />;

  return (
    <div className="space-y-3 p-4" dir="rtl">
      <h1 className="font-display text-xl font-700 text-slate-900">زياراتي</h1>
      {visits.length === 0 ? (
        <EmptyState icon={<ClipboardCheck size={32} className="text-slate-300" />} title="لا توجد زيارات" description="لم يتم تعيين زيارات لك بعد." />
      ) : (
        visits.map((v) => (
          <button key={v.id} onClick={() => setSelected(v)} className="card flex w-full items-center gap-3 p-4 text-right transition hover:shadow-glow">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-brand-50">
              <ClipboardCheck size={20} className="text-brand-600" />
            </div>
            <div className="flex-1">
              <p className="font-600 text-slate-900">{getClientName(v)}</p>
              <p className="text-xs text-slate-500">{formatDate(v.scheduled_date)} {v.scheduled_start_time ? `• ${formatTime(v.scheduled_start_time)}` : ''}</p>
              <p className="text-xs text-slate-400">{getClientAddress(v)}</p>
            </div>
            <span className={cn('rounded-full px-2.5 py-0.5 text-xs font-600', statusBadgeClass(v.status))}>
              {VISIT_STATUS_LABELS[v.status] ?? v.status}
            </span>
          </button>
        ))
      )}
      {selected && <VisitDetailModal visit={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}

/* ===== Worker QR ===== */

export function WorkerQr() {
  const { session } = useAuth();
  const { add } = useToast();
  const [visits, setVisits] = useState<VisitWithRelations[]>([]);
  const [result, setResult] = useState<{ ok: boolean; msg: string } | null>(null);
  const employeeId = session?.profile?.employee_id;

  useEffect(() => {
    if (!employeeId) return;
    (async () => { try { setVisits(await visitService.getByEmployee(employeeId)); } catch { /* */ } })();
  }, [employeeId]);

  const handleScan = async (code: string) => {
    try {
      const qrResult = await qrService.validate(code);
      if (!qrResult.valid) { setResult({ ok: false, msg: 'رمز QR غير صالح' }); return; }

      const visit = visits.find((v) => {
        const cid = v.contract?.client?.id ?? v.client?.id;
        return cid === qrResult.clientId;
      });

      if (!visit) { setResult({ ok: false, msg: 'هذا الرمز لا ينتمي لأي زيارة معينة لك' }); return; }

      if (visit.status === 'scheduled') {
        await visitService.startVisit(visit.id);
        setResult({ ok: true, msg: 'تم بدء الزيارة بنجاح' });
        add('تم بدء الزيارة', 'success');
      } else if (visit.status === 'started') {
        await visitService.finishVisit(visit.id);
        setResult({ ok: true, msg: 'تم إنهاء الزيارة بنجاح' });
        add('تم إنهاء الزيارة', 'success');
      } else {
        setResult({ ok: false, msg: 'لا يمكن إجراء عملية على هذه الزيارة' });
      }
    } catch (err) {
      setResult({ ok: false, msg: (err as Error).message });
    }
  };

  return (
    <div className="space-y-4 p-4" dir="rtl">
      <h1 className="font-display text-xl font-700 text-slate-900">مسح QR</h1>
      <p className="text-sm text-slate-500">امسح رمز QR الخاص بالعميل لبدء أو إنهاء الزيارة.</p>
      <QrScanner onScan={handleScan} />
      {result && (
        <div className={cn('rounded-lg p-4 text-sm font-600', result.ok ? 'bg-success-50 text-success-700' : 'bg-danger-50 text-danger-700')}>
          {result.msg}
        </div>
      )}
    </div>
  );
}

/* ===== Worker Profile ===== */

export function WorkerProfile() {
  const { session, logout } = useAuth();
  const navigate = useNavigate();
  const { add } = useToast();
  const employee = session?.profile?.employee;
  const [phone, setPhone] = useState(employee?.phone_number ?? '');
  const [photoUrl, setPhotoUrl] = useState(employee?.photo_url ?? '');
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!employee?.id) return;
    setSaving(true);
    try {
      const { error } = await supabase
        .from('employees')
        .update({ phone_number: phone, photo_url: photoUrl || null, updated_at: new Date().toISOString() })
        .eq('id', employee.id);
      if (error) throw error;
      add('تم حفظ التغييرات', 'success');
    } catch {
      add('فشل الحفظ', 'error');
    } finally { setSaving(false); }
  };

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  return (
    <div className="space-y-4 p-4" dir="rtl">
      <h1 className="font-display text-xl font-700 text-slate-900">الملف الشخصي</h1>

      <div className="card p-5">
        <div className="mb-4 flex items-center gap-3">
          <div className="flex h-16 w-16 items-center justify-center overflow-hidden rounded-full bg-brand-100 text-xl font-700 text-brand-700">
            {photoUrl ? <img src={photoUrl} alt="" className="h-full w-full object-cover" /> : (employee?.full_name?.charAt(0) ?? '?')}
          </div>
          <div>
            <p className="font-600 text-slate-900">{employee?.full_name ?? '—'}</p>
            <p className="text-sm text-slate-500">{employee?.job_title ?? employee?.position ?? ''}</p>
            <p className="text-xs text-slate-400">{employee?.service_area ?? ''}</p>
          </div>
        </div>

        <div className="space-y-3">
          <div>
            <label className="label">رقم الهاتف</label>
            <input className="input" value={phone} onChange={(e) => setPhone(e.target.value)} dir="ltr" />
          </div>
          <div>
            <label className="label">رابط الصورة</label>
            <input className="input" value={photoUrl} onChange={(e) => setPhotoUrl(e.target.value)} dir="ltr" placeholder="https://..." />
          </div>
          <button onClick={handleSave} disabled={saving} className="btn-primary w-full">
            {saving ? 'جاري الحفظ...' : 'حفظ'}
          </button>
        </div>
      </div>

      <button onClick={handleLogout} className="flex w-full items-center justify-center gap-2 rounded-lg bg-danger-50 py-3 text-sm font-600 text-danger-600">
        <LogOut size={18} /> تسجيل الخروج
      </button>
    </div>
  );
}
