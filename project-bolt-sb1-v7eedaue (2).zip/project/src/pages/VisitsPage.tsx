import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Calendar, Search, QrCode, PlayCircle, CheckCircle2, Clock, MapPin,
  Lock, User, ChevronRight, Filter,
} from 'lucide-react';
import { visitService } from '@/services/visitService';
import type { VisitWithRelations } from '@/types';
import { notificationService } from '@/services/notificationService';
import { auditService } from '@/services/auditService';
import { PageLoader, EmptyState } from '@/components/Feedback';
import { StatusBadge } from '@/components/Badge';
import { Modal } from '@/components/Modal';
import { useToast } from '@/components/Toast';
import { formatDate, formatDateTime, initials, cn } from '@/lib/utils';
import { VISIT_STATUS_LABELS } from '@/lib/locale';

type StatusFilter = 'all' | 'pending' | 'scheduled' | 'started' | 'completed' | 'archived';

export function VisitsPage() {
  const toast = useToast();
  const navigate = useNavigate();
  const [visits, setVisits] = useState<VisitWithRelations[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [scanVisit, setScanVisit] = useState<VisitWithRelations | null>(null);
  const [scanning, setScanning] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      setVisits(await visitService.list());
    } catch (err) {
      toast.push('error', (err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const filtered = visits.filter((v) => {
    const matchesStatus = statusFilter === 'all' || v.status === statusFilter;
    const clientName = v.contract?.client?.full_name ?? '';
    const empName = v.employee?.full_name ?? '';
    const matchesQuery =
      clientName.toLowerCase().includes(query.toLowerCase()) ||
      empName.toLowerCase().includes(query.toLowerCase()) ||
      v.contract?.contract_number?.toLowerCase().includes(query.toLowerCase());
    return matchesStatus && matchesQuery;
  });

  const startVisit = async (visit: VisitWithRelations) => {
    setScanning(true);
    try {
      await visitService.startVisit(visit.id);
      await notificationService.notifyVisitStarted(visit.id, visit.contract?.client?.full_name ?? 'client');
      await auditService.log({ action: 'qr_scan_start', entityType: 'visit', entityId: visit.id, newValue: { status: 'started' } });
      toast.push('success', 'تم بدء الزيارة. امسح مرة أخرى للإنهاء.');
      setScanVisit(null);
      await load();
    } catch (err) {
      toast.push('error', (err as Error).message);
    } finally {
      setScanning(false);
    }
  };

  const finishVisit = async (visit: VisitWithRelations) => {
    setScanning(true);
    try {
      await visitService.finishVisit(visit.id);
      await notificationService.notifyVisitCompleted(visit.id, visit.contract?.client?.full_name ?? 'client');
      await auditService.log({ action: 'qr_scan_finish', entityType: 'visit', entityId: visit.id, newValue: { status: 'completed' } });
      toast.push('success', 'تم إكمال الزيارة وقفلها.');
      setScanVisit(null);
      await load();
    } catch (err) {
      toast.push('error', (err as Error).message);
    } finally {
      setScanning(false);
    }
  };

  if (loading) return <PageLoader label="جارٍ تحميل الزيارات…" />;

  const statusCounts = {
    all: visits.length,
    pending: visits.filter((v) => v.status === 'pending').length,
    scheduled: visits.filter((v) => v.status === 'scheduled').length,
    started: visits.filter((v) => v.status === 'started').length,
    completed: visits.filter((v) => v.status === 'completed').length,
    archived: visits.filter((v) => v.status === 'archived').length,
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="font-display text-2xl font-700 text-slate-50">الزيارات</h1>
        <p className="mt-1 text-sm text-slate-400">إكمال دورة حياة الزيارة. الزيارات مُولّدة من العقود — ولا تُنشأ يدوياً أبداً.</p>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        {(Object.keys(statusCounts) as StatusFilter[]).map((s) => (
          <button
            key={s}
            onClick={() => setStatusFilter(s)}
            className={cn(
              'rounded-lg px-3 py-1.5 text-sm font-500 capitalize transition',
              statusFilter === s ? 'bg-brand-500 text-white' : 'border-slate-200/80 text-slate-500 hover:bg-slate-100/50',
            )}
          >
            {s === 'all' ? 'الكل' : (VISIT_STATUS_LABELS[s] ?? s)} ({statusCounts[s]})
          </button>
        ))}
      </div>

      <div className="relative max-w-md">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
        <input className="input pl-9" placeholder="بحث حسب العميل أو الموظف أو العقد…" value={query} onChange={(e) => setQuery(e.target.value)} />
      </div>

      {filtered.length === 0 ? (
        <div className="card"><EmptyState icon={<Calendar size={32} />} title="لا توجد زيارات" description="الزيارات تُنشأ تلقائياً عند تفعيل عقد." /></div>
      ) : (
        <div className="space-y-3">
          {filtered.map((v) => {
            const clientName = v.contract?.client?.full_name ?? '—';
            const isLocked = v.status === 'completed' || v.status === 'archived';
            return (
              <div key={v.id} className="card card-hover p-4">
                <div className="flex flex-wrap items-center gap-4">
                  <div className="flex items-center gap-3">
                    <span className="flex h-10 w-10 items-center justify-center rounded-full bg-brand-50 text-xs font-700 text-brand-600">
                      {v.visit_index ?? '—'}
                    </span>
                    <div>
                      <p className="font-600 text-slate-900">{clientName}</p>
                      <p className="text-xs text-slate-500">{v.contract?.contract_number} · {v.contract?.package?.name}</p>
                    </div>
                  </div>

                  <div className="ml-auto flex flex-wrap items-center gap-4 text-sm">
                    <div className="flex items-center gap-1.5 text-slate-400">
                      <Calendar size={14} />
                      {formatDate(v.scheduled_date)}
                      {v.scheduled_start_time && <span className="text-slate-500">· {v.scheduled_start_time}</span>}
                    </div>
                    {v.employee && (
                      <div className="flex items-center gap-1.5 text-slate-400">
                        <span className="flex h-6 w-6 items-center justify-center rounded-full bg-brand-100 text-[10px] font-700 text-brand-500">{initials(v.employee.full_name)}</span>
                        {v.employee.full_name}
                      </div>
                    )}
                    <StatusBadge status={v.status} label={VISIT_STATUS_LABELS[v.status] ?? v.status} />
                  </div>
                </div>

                {(v.started_at || v.finished_at) && (
                  <div className="mt-3 flex flex-wrap gap-4 border-t border-slate-200/80 pt-3 text-xs text-slate-500">
                    {v.started_at && <span className="flex items-center gap-1"><PlayCircle size={12} /> بدأت {formatDateTime(v.started_at)}</span>}
                    {v.finished_at && <span className="flex items-center gap-1"><CheckCircle2 size={12} /> انتهت {formatDateTime(v.finished_at)}</span>}
                    {(v.start_gps_lat != null) && <span className="flex items-center gap-1"><MapPin size={12} /> تم تسجيل الموقع</span>}
                    {isLocked && <span className="flex items-center gap-1 text-warning-400"><Lock size={12} /> مقفل</span>}
                  </div>
                )}

                <div className="mt-3 flex items-center gap-2">
                  {!isLocked && (
                    <button
                      onClick={() => setScanVisit(v)}
                      className="btn-ghost text-sm"
                    >
                      <QrCode size={14} /> {v.status === 'started' ? 'امسح للإنهاء' : 'امسح رمز QR'}
                    </button>
                  )}
                  <Link to={`/clients/${v.contract?.client_id}`} className="text-sm text-brand-600 hover:text-brand-800">
                    عرض العميل
                  </Link>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* QR Scan Modal */}
      <Modal
        open={!!scanVisit}
        onClose={() => setScanVisit(null)}
        title="التحقق عبر QR"
        subtitle={scanVisit ? `زيارة رقم ${scanVisit.visit_index} لـ ${scanVisit.contract?.client?.full_name ?? ''}` : ''}
        size="sm"
        footer={
          <>
            <button onClick={() => setScanVisit(null)} className="btn-ghost">إلغاء</button>
            {scanVisit && scanVisit.status !== 'started' && (
              <button onClick={() => startVisit(scanVisit)} disabled={scanning} className="btn-primary">
                {scanning ? 'جارٍ المسح…' : <><PlayCircle size={16} /> بدء الزيارة</>}
              </button>
            )}
            {scanVisit && scanVisit.status === 'started' && (
              <button onClick={() => finishVisit(scanVisit)} disabled={scanning} className="btn-primary">
                {scanning ? 'جارٍ المسح…' : <><CheckCircle2 size={16} /> إنهاء الزيارة</>}
              </button>
            )}
          </>
        }
      >
        <div className="space-y-4">
          <div className="flex flex-col items-center gap-3 rounded-xl border border-slate-200/80 bg-white/90 p-6">
            <div className="rounded-xl bg-brand-50 p-4">
              <QrCode size={48} className="text-brand-600" />
            </div>
            <p className="text-center text-sm text-slate-600">
              {scanVisit?.status === 'started'
                ? 'امسح رمز QR الخاص بالعميل لإنهاء وقفل هذه الزيارة.'
                : 'امسح رمز QR الخاص بالعميل لبدء هذه الزيارة. سيتم تسجيل الموقع والوقت.'}
            </p>
          </div>
          {scanVisit && (
            <div className="space-y-2 text-sm">
              <Row label="العميل" value={scanVisit.contract?.client?.full_name ?? '—'} />
              <Row label="التاريخ" value={formatDate(scanVisit.scheduled_date)} />
              <Row label="الوقت" value={`${scanVisit.scheduled_start_time ?? '—'} – ${scanVisit.scheduled_end_time ?? '—'}`} />
              <Row label="الحالة" value={VISIT_STATUS_LABELS[scanVisit.status] ?? scanVisit.status} />
            </div>
          )}
        </div>
      </Modal>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between">
      <span className="text-slate-500">{label}</span>
      <span className="font-500 text-slate-800">{value}</span>
    </div>
  );
}
