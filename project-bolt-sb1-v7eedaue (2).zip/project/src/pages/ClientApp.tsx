import { useState, useEffect } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import {
  Home, ClipboardCheck, CreditCard, Heart, UserCircle,
  LogOut, Phone, MapPin, Clock, Package, Send,
} from 'lucide-react';
import { ArkonLogo } from '@/components/ArkonLogo';
import { useAuth } from '@/lib/auth';
import { useToast } from '@/components/Toast';
import { visitService } from '@/services/visitService';
import { clientService } from '@/services/clientService';
import { supabase } from '@/lib/supabase';
import { PageLoader, EmptyState } from '@/components/Feedback';
import { formatDate, formatTime, formatCurrency, cn } from '@/lib/utils';
import { VISIT_STATUS_LABELS, PAYMENT_STATUS_LABELS } from '@/lib/locale';
import type { VisitWithRelations, Client } from '@/types';

/* ===== Helpers ===== */

function statusBadgeClass(status: string): string {
  switch (status) {
    case 'completed': return 'bg-success-50 text-success-700';
    case 'started': return 'bg-warning-50 text-warning-700';
    case 'cancelled': return 'bg-danger-50 text-danger-700';
    default: return 'bg-brand-50 text-brand-700';
  }
}

function payBadgeClass(status: string): string {
  switch (status) {
    case 'paid': return 'bg-success-50 text-success-700';
    case 'partial': return 'bg-warning-50 text-warning-700';
    case 'overdue': return 'bg-danger-50 text-danger-700';
    default: return 'bg-slate-100 text-slate-600';
  }
}

/* ===== ClientApp Layout ===== */

export function ClientApp() {
  const { session } = useAuth();
  const clientName = session?.client?.full_name ?? 'العميل';

  return (
    <div className="flex min-h-screen flex-col bg-slate-50" dir="rtl">
      <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-slate-200/60 bg-white/95 px-4 backdrop-blur">
        <ArkonLogo size={28} withWordmark variant="compact" />
        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-100 text-sm font-600 text-brand-700">
          {clientName.charAt(0)}
        </div>
      </header>

      <main className="mx-auto w-full max-w-md flex-1 pb-20">
        <Outlet />
      </main>

      <nav className="fixed inset-x-0 bottom-0 z-30 mx-auto flex max-w-md items-center justify-around border-t border-slate-200/60 bg-white/95 px-1 py-2 backdrop-blur">
        <NavLink to="/client" end className={({ isActive }) => cn('flex flex-col items-center gap-0.5 px-2 py-1.5 text-[11px] font-500 transition', isActive ? 'text-brand-700' : 'text-slate-400')}>
          <Home size={20} /> الرئيسية
        </NavLink>
        <NavLink to="/client/visits" className={({ isActive }) => cn('flex flex-col items-center gap-0.5 px-2 py-1.5 text-[11px] font-500 transition', isActive ? 'text-brand-700' : 'text-slate-400')}>
          <ClipboardCheck size={20} /> الزيارات
        </NavLink>
        <NavLink to="/client/invoices" className={({ isActive }) => cn('flex flex-col items-center gap-0.5 px-2 py-1.5 text-[11px] font-500 transition', isActive ? 'text-brand-700' : 'text-slate-400')}>
          <CreditCard size={20} /> الفواتير
        </NavLink>
        <NavLink to="/client/support" className={({ isActive }) => cn('flex flex-col items-center gap-0.5 px-2 py-1.5 text-[11px] font-500 transition', isActive ? 'text-brand-700' : 'text-slate-400')}>
          <Heart size={20} /> الدعم
        </NavLink>
        <NavLink to="/client/profile" className={({ isActive }) => cn('flex flex-col items-center gap-0.5 px-2 py-1.5 text-[11px] font-500 transition', isActive ? 'text-brand-700' : 'text-slate-400')}>
          <UserCircle size={20} /> الملف
        </NavLink>
      </nav>
    </div>
  );
}

/* ===== Client Home ===== */

export function ClientHome() {
  const { session } = useAuth();
  const navigate = useNavigate();
  const [visits, setVisits] = useState<VisitWithRelations[]>([]);
  const [unpaidCount, setUnpaidCount] = useState(0);
  const [activePackage, setActivePackage] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [showRequest, setShowRequest] = useState(false);

  const clientId = session?.userId;
  const client = session?.client as Client | null;
  const clientName = client?.full_name ?? 'العميل';

  useEffect(() => {
    if (!clientId) { setLoading(false); return; }
    (async () => {
      try {
        const [v, inv, contracts] = await Promise.all([
          visitService.getByClient(clientId),
          supabase.from('invoices').select('status').eq('contract.client_id', clientId).neq('status', 'paid'),
          supabase.from('contracts').select('*, package:packages(name)').eq('client_id', clientId).eq('status', 'active').order('created_at', { ascending: false }).limit(1).maybeSingle(),
        ]);
        setVisits(v);
        setUnpaidCount(inv.data?.length ?? 0);
        setActivePackage((contracts.data as any)?.package?.name ?? null);
      } catch { /* */ } finally { setLoading(false); }
    })();
  }, [clientId]);

  if (loading) return <PageLoader label="جاري التحميل..." />;

  const upcoming = visits.filter((v) => v.status === 'scheduled' || v.status === 'started').slice(0, 3);

  return (
    <div className="space-y-4 p-4" dir="rtl">
      <div>
        <h1 className="font-display text-xl font-700 text-slate-900">مرحباً، {clientName}</h1>
        <p className="text-sm text-slate-500">حسابك في ARKON</p>
      </div>

      {activePackage && (
        <div className="card flex items-center gap-3 p-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-brand-50">
            <Package size={20} className="text-brand-600" />
          </div>
          <div className="flex-1">
            <p className="text-xs text-slate-400">الباقة الحالية</p>
            <p className="font-600 text-slate-900">{activePackage}</p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 gap-3">
        <button onClick={() => navigate('/client/visits')} className="card p-4 text-right transition hover:shadow-glow">
          <ClipboardCheck size={20} className="text-brand-600" />
          <p className="mt-2 text-2xl font-700 text-slate-900">{upcoming.length}</p>
          <p className="text-xs text-slate-500">زيارات قادمة</p>
        </button>
        <button onClick={() => navigate('/client/invoices')} className="card p-4 text-right transition hover:shadow-glow">
          <CreditCard size={20} className="text-warning-600" />
          <p className="mt-2 text-2xl font-700 text-slate-900">{unpaidCount}</p>
          <p className="text-xs text-slate-500">فواتير غير مدفوعة</p>
        </button>
      </div>

      <div>
        <h2 className="mb-2 text-sm font-600 text-slate-700">الزيارات القادمة</h2>
        {upcoming.length === 0 ? (
          <EmptyState icon={<ClipboardCheck size={28} className="text-slate-300" />} title="لا زيارات قادمة" />
        ) : (
          <div className="space-y-2">
            {upcoming.map((v) => (
              <div key={v.id} className="card flex items-center gap-3 p-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-50">
                  <Clock size={18} className="text-brand-600" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-600 text-slate-900">{formatDate(v.scheduled_date)}</p>
                  <p className="text-xs text-slate-500">{v.scheduled_start_time ? formatTime(v.scheduled_start_time) : ''} • {v.employee?.full_name ?? 'غير معين'}</p>
                </div>
                <span className={cn('rounded-full px-2 py-0.5 text-xs font-600', statusBadgeClass(v.status))}>
                  {VISIT_STATUS_LABELS[v.status] ?? v.status}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      <button onClick={() => setShowRequest(true)} className="btn-primary w-full">
        طلب خدمة جديدة
      </button>

      {showRequest && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-900/50 backdrop-blur-sm sm:items-center" dir="rtl">
          <div className="w-full max-w-md rounded-t-2xl bg-white p-5 shadow-xl sm:rounded-2xl">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-display text-lg font-700 text-slate-900">طلب خدمة جديدة</h2>
              <button onClick={() => setShowRequest(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>
            <p className="text-sm text-slate-500">سيتم التواصل معك من قبل فريق المبيعات لتأكيد طلبك. يرجى الاتصال على رقم الدعم.</p>
            <button onClick={() => setShowRequest(false)} className="btn-primary mt-4 w-full">حسناً</button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ===== Client Visits ===== */

export function ClientVisits() {
  const { session } = useAuth();
  const [visits, setVisits] = useState<VisitWithRelations[]>([]);
  const [loading, setLoading] = useState(true);
  const clientId = session?.userId;

  useEffect(() => {
    if (!clientId) { setLoading(false); return; }
    (async () => {
      try { setVisits(await visitService.getByClient(clientId)); }
      catch { /* */ } finally { setLoading(false); }
    })();
  }, [clientId]);

  if (loading) return <PageLoader label="جاري التحميل..." />;

  const upcoming = visits.filter((v) => v.status === 'scheduled' || v.status === 'started');
  const history = visits.filter((v) => v.status === 'completed' || v.status === 'cancelled');

  return (
    <div className="space-y-4 p-4" dir="rtl">
      <h1 className="font-display text-xl font-700 text-slate-900">زياراتي</h1>

      {upcoming.length > 0 && (
        <div>
          <h2 className="mb-2 text-sm font-600 text-slate-700">الزيارات القادمة</h2>
          <div className="space-y-2">
            {upcoming.map((v) => (
              <div key={v.id} className="card flex items-center gap-3 p-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-50">
                  <Clock size={18} className="text-brand-600" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-600 text-slate-900">{formatDate(v.scheduled_date)}</p>
                  <p className="text-xs text-slate-500">{v.scheduled_start_time ? formatTime(v.scheduled_start_time) : ''} • {v.employee?.full_name ?? 'غير معين'}</p>
                </div>
                <span className={cn('rounded-full px-2 py-0.5 text-xs font-600', statusBadgeClass(v.status))}>
                  {VISIT_STATUS_LABELS[v.status] ?? v.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div>
        <h2 className="mb-2 text-sm font-600 text-slate-700">سجل الزيارات</h2>
        {history.length === 0 ? (
          <EmptyState icon={<ClipboardCheck size={28} className="text-slate-300" />} title="لا يوجد سجل" />
        ) : (
          <div className="space-y-2">
            {history.map((v) => (
              <div key={v.id} className="card flex items-center gap-3 p-3 opacity-80">
                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-slate-100">
                  <ClipboardCheck size={18} className="text-slate-400" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-600 text-slate-900">{formatDate(v.scheduled_date)}</p>
                  <p className="text-xs text-slate-500">{v.employee?.full_name ?? 'غير معين'}</p>
                </div>
                <span className={cn('rounded-full px-2 py-0.5 text-xs font-600', statusBadgeClass(v.status))}>
                  {VISIT_STATUS_LABELS[v.status] ?? v.status}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* ===== Client Invoices ===== */

export function ClientInvoices() {
  const { session } = useAuth();
  const [invoices, setInvoices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const clientId = session?.userId;

  useEffect(() => {
    if (!clientId) { setLoading(false); return; }
    (async () => {
      try {
        const { data } = await supabase
          .from('invoices')
          .select('*, contract:contracts!inner(client_id)')
          .eq('contract.client_id', clientId)
          .order('created_at', { ascending: false });
        setInvoices(data ?? []);
      } catch { /* */ } finally { setLoading(false); }
    })();
  }, [clientId]);

  if (loading) return <PageLoader label="جاري التحميل..." />;

  return (
    <div className="space-y-4 p-4" dir="rtl">
      <h1 className="font-display text-xl font-700 text-slate-900">الفواتير</h1>
      {invoices.length === 0 ? (
        <EmptyState icon={<CreditCard size={28} className="text-slate-300" />} title="لا توجد فواتير" />
      ) : (
        <div className="space-y-2">
          {invoices.map((inv) => (
            <div key={inv.id} className="card p-4">
              <div className="flex items-center justify-between">
                <p className="font-600 text-slate-900">#{inv.invoice_number ?? inv.id.slice(0, 8)}</p>
                <span className={cn('rounded-full px-2.5 py-0.5 text-xs font-600', payBadgeClass(inv.status))}>
                  {PAYMENT_STATUS_LABELS[inv.status] ?? inv.status}
                </span>
              </div>
              <p className="mt-1 text-lg font-700 text-slate-900">{formatCurrency(inv.total_amount ?? inv.amount ?? 0)}</p>
              <p className="text-xs text-slate-500">{formatDate(inv.created_at)}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ===== Client Support ===== */

export function ClientSupport() {
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [tickets, setTickets] = useState<{ id: string; subject: string; message: string; date: string }[]>([]);
  const { add } = useToast();

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim() || !message.trim()) return;
    setTickets((prev) => [{ id: Date.now().toString(), subject, message, date: new Date().toISOString() }, ...prev]);
    setSubject('');
    setMessage('');
    add('تم إرسال طلب الدعم', 'success');
  };

  return (
    <div className="space-y-4 p-4" dir="rtl">
      <h1 className="font-display text-xl font-700 text-slate-900">الدعم</h1>

      <form onSubmit={submit} className="card space-y-3 p-4">
        <div>
          <label className="label">الموضوع</label>
          <input className="input" value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="موضوع الطلب" />
        </div>
        <div>
          <label className="label">الرسالة</label>
          <textarea className="input min-h-[100px]" value={message} onChange={(e) => setMessage(e.target.value)} placeholder="اكتب رسالتك هنا..." />
        </div>
        <button type="submit" className="btn-primary w-full">
          <Send size={16} /> إرسال
        </button>
      </form>

      {tickets.length > 0 && (
        <div>
          <h2 className="mb-2 text-sm font-600 text-slate-700">طلبات سابقة</h2>
          <div className="space-y-2">
            {tickets.map((t) => (
              <div key={t.id} className="card p-3">
                <p className="text-sm font-600 text-slate-900">{t.subject}</p>
                <p className="mt-1 text-xs text-slate-500">{t.message}</p>
                <p className="mt-1 text-xs text-slate-400">{formatDate(t.date)}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

/* ===== Client Profile ===== */

export function ClientProfile() {
  const { session, logout } = useAuth();
  const navigate = useNavigate();
  const { add } = useToast();
  const client = session?.client as Client | null;
  const [phone, setPhone] = useState(client?.phone_number ?? '');
  const [email, setEmail] = useState(client?.email ?? '');
  const [address, setAddress] = useState(client?.address ?? '');
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!client?.id) return;
    setSaving(true);
    try {
      await clientService.update(client.id, { phone_number: phone, email, address });
      add('تم حفظ التغييرات', 'success');
    } catch {
      add('فشل الحفظ', 'error');
    } finally { setSaving(false); }
  };

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  return (
    <div className="space-y-4 p-4" dir="rtl">
      <h1 className="font-display text-xl font-700 text-slate-900">الملف الشخصي</h1>

      <div className="card p-5">
        <div className="mb-4 flex items-center gap-3">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-brand-100 text-xl font-700 text-brand-700">
            {client?.full_name?.charAt(0) ?? '?'}
          </div>
          <div>
            <p className="font-600 text-slate-900">{client?.full_name ?? '—'}</p>
            <p className="text-sm text-slate-500">{client?.service_area ?? ''}</p>
          </div>
        </div>

        <div className="space-y-3">
          <div>
            <label className="label">رقم الهاتف</label>
            <input className="input" value={phone} onChange={(e) => setPhone(e.target.value)} dir="ltr" />
          </div>
          <div>
            <label className="label">البريد الإلكتروني</label>
            <input className="input" value={email} onChange={(e) => setEmail(e.target.value)} dir="ltr" />
          </div>
          <div>
            <label className="label">العنوان</label>
            <input className="input" value={address} onChange={(e) => setAddress(e.target.value)} />
          </div>
          <button onClick={handleSave} disabled={saving} className="btn-primary w-full">
            {saving ? 'جاري الحفظ...' : 'حفظ'}
          </button>
        </div>
      </div>

      <button onClick={handleLogout} className="flex w-full items-center justify-center gap-2 rounded-lg bg-danger-50 py-3 text-sm font-600 text-danger-600">
        <LogOut size={18} /> تسجيل الخروج
      </button>
    </div>
  );
}
