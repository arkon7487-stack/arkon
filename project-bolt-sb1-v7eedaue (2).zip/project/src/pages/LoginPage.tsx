import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Mail, Lock, Phone, ArrowRight, ShieldCheck, UserRound } from 'lucide-react';
import { ArkonLogo } from '@/components/ArkonLogo';
import { Spinner } from '@/components/Feedback';
import { useAuth } from '@/lib/auth';
import { getDefaultRoute } from '@/lib/navigation';

type Tab = 'staff' | 'client';

export function LoginPage() {
  const { staffLogin, clientLogin } = useAuth();
  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>('staff');

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submitStaff = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const session = await staffLogin(email, password);
      navigate(getDefaultRoute(session.permissions ?? [], 'staff'));
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  const submitClient = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const session = await clientLogin(phone);
      navigate(getDefaultRoute(session.permissions ?? [], 'client'));
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-slate-50 px-4 py-10" dir="rtl">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -left-40 -top-40 h-96 w-96 rounded-full bg-brand-200/40 blur-[120px]" />
        <div className="absolute -bottom-40 -right-32 h-96 w-96 rounded-full bg-brand-100/50 blur-[120px]" />
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{ backgroundImage: 'linear-gradient(#1952d0 1px, transparent 1px), linear-gradient(90deg, #1952d0 1px, transparent 1px)', backgroundSize: '48px 48px' }}
        />
      </div>

      <div className="relative w-full max-w-md">
        <div className="mb-8 flex flex-col items-center text-center">
          <ArkonLogo size={56} />
          <h1 className="mt-5 font-display text-2xl font-700 tracking-tight text-slate-900">ARKON</h1>
          <p className="mt-1 text-sm text-slate-500">منصة إدارة العمليات الميدانية للمؤسسات</p>
        </div>

        <div className="card animate-fade-in p-6 sm:p-8">
          <div className="mb-6 grid grid-cols-2 gap-1 rounded-xl bg-slate-100 p-1">
            <button
              onClick={() => { setTab('staff'); setError(null); }}
              className={`flex items-center justify-center gap-2 rounded-lg py-2.5 text-sm font-600 transition ${tab === 'staff' ? 'bg-white text-brand-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
            >
              <ShieldCheck size={16} /> موظف
            </button>
            <button
              onClick={() => { setTab('client'); setError(null); }}
              className={`flex items-center justify-center gap-2 rounded-lg py-2.5 text-sm font-600 transition ${tab === 'client' ? 'bg-white text-brand-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
            >
              <UserRound size={16} /> عميل
            </button>
          </div>

          {error && (
            <div className="mb-4 rounded-lg border border-danger-200 bg-danger-50 px-3.5 py-2.5 text-sm text-danger-600">
              {error}
            </div>
          )}

          {tab === 'staff' ? (
            <form onSubmit={submitStaff} className="space-y-4">
              <div>
                <label className="label">البريد الإلكتروني</label>
                <div className="relative">
                  <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input className="input pl-10" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="islam@gmail.com" required />
                </div>
              </div>
              <div>
                <label className="label">كلمة المرور</label>
                <div className="relative">
                  <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input className="input pl-10" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" required />
                </div>
              </div>
              <button type="submit" disabled={loading} className="btn-primary w-full">
                {loading ? <Spinner /> : <>تسجيل الدخول <ArrowRight size={16} /></>}
              </button>
            </form>
          ) : (
            <form onSubmit={submitClient} className="space-y-4">
              <div>
                <label className="label">رقم الهاتف</label>
                <div className="relative">
                  <Phone size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input className="input pl-10" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+972 59 000 0000" required />
                </div>
                <p className="mt-2 text-xs text-slate-500">يمكن تسجيل الدخول فقط بأرقام الهواتف المسجلة في ARKON.</p>
              </div>
              <button type="submit" disabled={loading} className="btn-primary w-full">
                {loading ? <Spinner /> : <>دخول <ArrowRight size={16} /></>}
              </button>
            </form>
          )}
        </div>

        <p className="mt-6 text-center text-xs text-slate-500">
          ARKON · منصة العمليات المركزية
        </p>
      </div>
    </div>
  );
}
