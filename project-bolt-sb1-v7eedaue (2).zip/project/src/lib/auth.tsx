import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { supabase } from '@/lib/supabase';
import { authService } from '@/services/authService';
import { permissionService } from '@/services/permissionService';
import type { AuthSession, Client } from '@/types';

const CLIENT_PHONE_KEY = 'arkon_client_phone';

const CLIENT_PERMS = ['client_home', 'client_visits', 'client_invoices', 'client_support', 'client_profile'];

interface AuthContextValue {
  session: AuthSession | null;
  permissions: string[];
  loading: boolean;
  staffLogin: (email: string, password: string) => Promise<AuthSession>;
  clientLogin: (phone: string) => Promise<AuthSession>;
  logout: () => Promise<void>;
  refresh: () => Promise<void>;
  hasPermission: (key: string) => boolean;
}

const AuthContext = createContext<AuthContextValue | null>(null);

async function loadStaffSession(): Promise<{ session: AuthSession; permissions: string[] } | null> {
  const { data } = await supabase.auth.getUser();
  const userId = data.user?.id;
  if (!userId) return null;
  const profile = await authService.getCurrentProfile();
  if (!profile) return null;
  const perms = profile.role?.id ? await permissionService.getForRole(profile.role.id) : [];
  return {
    session: { kind: 'staff', userId, profile, role: profile?.role ?? null, permissions: perms },
    permissions: perms,
  };
}

async function loadClientSession(): Promise<{ session: AuthSession; permissions: string[] } | null> {
  const phone = localStorage.getItem(CLIENT_PHONE_KEY);
  if (!phone) return null;
  const { data: client } = await supabase
    .from('clients')
    .select('*')
    .eq('phone_number', phone)
    .maybeSingle();
  if (!client) return null;
  return {
    session: { kind: 'client', userId: (client as Client).id, client: client as Client, role: null, permissions: CLIENT_PERMS },
    permissions: CLIENT_PERMS,
  };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<AuthSession | null>(null);
  const [permissions, setPermissions] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = async () => {
    const result = (await loadStaffSession()) ?? (await loadClientSession());
    setSession(result?.session ?? null);
    setPermissions(result?.permissions ?? []);
  };

  useEffect(() => {
    (async () => {
      await refresh();
      setLoading(false);
    })();

    const { data: sub } = supabase.auth.onAuthStateChange((_event, supaSession) => {
      (async () => {
        if (supaSession?.user) {
          const profile = await authService.getCurrentProfile();
          if (profile) {
            const perms = profile.role?.id ? await permissionService.getForRole(profile.role.id) : [];
            setSession({ kind: 'staff', userId: supaSession.user.id, profile, role: profile?.role ?? null, permissions: perms });
            setPermissions(perms);
          }
        }
      })();
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  const staffLogin = async (email: string, password: string): Promise<AuthSession> => {
    const { profile, role } = await authService.signInWithPassword(email, password);
    const perms = profile?.role?.id ? await permissionService.getForRole(profile.role.id) : [];
    const s: AuthSession = { kind: 'staff', userId: profile?.user_id ?? '', profile, role, permissions: perms };
    setSession(s);
    setPermissions(perms);
    return s;
  };

  const clientLogin = async (phone: string): Promise<AuthSession> => {
    const { data: client, error } = await supabase
      .from('clients')
      .select('*')
      .eq('phone_number', phone)
      .maybeSingle();
    if (error) throw new Error('حدث خطأ أثناء البحث عن الحساب');
    if (!client) throw new Error('لم يتم العثور على حساب عميل بهذا الرقم');
    localStorage.setItem(CLIENT_PHONE_KEY, phone);
    const s: AuthSession = { kind: 'client', userId: (client as Client).id, client: client as Client, role: null, permissions: CLIENT_PERMS };
    setSession(s);
    setPermissions(CLIENT_PERMS);
    return s;
  };

  const logout = async () => {
    if (session?.kind === 'staff') {
      await authService.signOut();
    }
    localStorage.removeItem(CLIENT_PHONE_KEY);
    setSession(null);
    setPermissions([]);
  };

  const hasPermission = (key: string): boolean => {
    if (!session) return false;
    if (session.kind === 'staff' && session.role?.key === 'super_admin') return true;
    return permissions.includes(key);
  };

  return (
    <AuthContext.Provider value={{ session, permissions, loading, staffLogin, clientLogin, logout, refresh, hasPermission }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
