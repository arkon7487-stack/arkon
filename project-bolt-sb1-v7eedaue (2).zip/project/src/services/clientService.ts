import { supabase } from '@/lib/supabase';
import { ARKON_COMPANY_ID } from '@/lib/supabase';
import type { Client } from '@/types';

export interface ClientInput {
  full_name: string;
  phone_number: string;
  email?: string;
  address?: string;
  service_area?: string;
  date_of_birth?: string;
  gender?: string;
  notes?: string;
  status?: string;
  medical_conditions?: string;
  allergies?: string;
  blood_type?: string;
  emergency_contact_name?: string;
  emergency_contact_phone?: string;
  emergency_contact_relation?: string;
}

export const clientService = {
  async list(): Promise<Client[]> {
    const { data, error } = await supabase
      .from('clients')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return (data as Client[]) ?? [];
  },

  async get(id: string): Promise<Client | null> {
    const { data, error } = await supabase
      .from('clients')
      .select('*')
      .eq('id', id)
      .maybeSingle();
    if (error) throw error;
    return (data as Client) ?? null;
  },

  async create(input: ClientInput): Promise<Client> {
    const { data, error } = await supabase
      .from('clients')
      .insert({ ...input, company_id: ARKON_COMPANY_ID, status: input.status ?? 'active' })
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data as Client;
  },

  async update(id: string, patch: Partial<ClientInput>): Promise<Client> {
    const { data, error } = await supabase
      .from('clients')
      .update({ ...patch, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data as Client;
  },

  async remove(id: string): Promise<void> {
    const client = await this.get(id);
    if (!client) throw new Error('العميل غير موجود');
    const clientName = client.full_name;

    // 1. Archive invoices — preserve financial history
    const { data: contracts } = await supabase
      .from('contracts')
      .select('id')
      .eq('client_id', id);
    const contractIds = (contracts ?? []).map((c: { id: string }) => c.id);

    if (contractIds.length > 0) {
      // Archive invoices linked to this client's contracts
      await supabase
        .from('invoices')
        .update({ archived: true, archive_reason: 'Archived – Customer Deleted', archived_client_name: clientName })
        .in('contract_id', contractIds);

      // Archive payments linked to those invoices
      const { data: invoices } = await supabase
        .from('invoices')
        .select('id')
        .in('contract_id', contractIds);
      const invoiceIds = (invoices ?? []).map((i: { id: string }) => i.id);
      if (invoiceIds.length > 0) {
        await supabase
          .from('payments')
          .update({ archived: true, archive_reason: 'Archived – Customer Deleted' })
          .in('invoice_id', invoiceIds);
      }
    }

    // 2. Delete visits for all contracts of this client
    if (contractIds.length > 0) {
      await supabase.from('visits').delete().in('contract_id', contractIds);
    }

    // 3. Delete contracts (client_id FK is now SET NULL, but we want them gone)
    await supabase.from('contracts').delete().eq('client_id', id);

    // 4. Delete QR code
    await supabase.from('qr_codes').delete().eq('client_id', id);

    // 5. Delete notifications related to this client (via title match is not safe, skip)
    // Notifications don't have a client_id FK, so we skip this step

    // 6. Mark opportunities as lost
    await supabase
      .from('opportunities')
      .update({ status: 'lost', updated_at: new Date().toISOString() })
      .eq('converted_client_id', id);

    // 7. Delete activity timeline entries for this client
    await supabase.from('activity_timeline').delete().eq('entity_type', 'client').eq('entity_id', id);

    // 8. Delete attachments
    await supabase.from('attachments').delete().eq('client_id', id);

    // 9. Finally delete the client
    const { error } = await supabase.from('clients').delete().eq('id', id);
    if (error) throw error;
  },

  async getProfile(id: string) {
    const [clientRes, contractsRes, visitsRes, attachmentsRes, invoicesRes, activityRes, qrRes] =
      await Promise.all([
        supabase.from('clients').select('*').eq('id', id).maybeSingle(),
        supabase
          .from('contracts')
          .select('*, package:packages(*), employee:employees(*)')
          .eq('client_id', id)
          .order('created_at', { ascending: false }),
        supabase
          .from('visits')
          .select('*, employee:employees(*), contract:contracts!inner(client_id)')
          .eq('contract.client_id', id)
          .order('scheduled_date', { ascending: false }),
        supabase.from('attachments').select('*').eq('client_id', id),
        supabase
          .from('invoices')
          .select('*, contract:contracts!inner(client_id)')
          .eq('contract.client_id', id)
          .order('created_at', { ascending: false }),
        supabase
          .from('activity_timeline')
          .select('*')
          .eq('entity_type', 'client')
          .eq('entity_id', id)
          .order('created_at', { ascending: false }),
        supabase.from('qr_codes').select('*').eq('client_id', id).maybeSingle(),
      ]);

    if (clientRes.error) throw clientRes.error;

    return {
      client: clientRes.data as Client | null,
      contracts: (contractsRes.data as any[]) ?? [],
      visits: (visitsRes.data as any[]) ?? [],
      attachments: (attachmentsRes.data as any[]) ?? [],
      invoices: (invoicesRes.data as any[]) ?? [],
      activity: (activityRes.data as any[]) ?? [],
      qrCode: (qrRes.data as any) ?? null,
    };
  },
};
