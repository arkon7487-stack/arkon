import { supabase } from '@/lib/supabase';
import type { NotificationItem } from '@/types';

export interface CreateNotificationInput {
  audience?: string;
  category?: string;
  title: string;
  body?: string;
  link?: string;
}

export const notificationService = {
  async list(): Promise<NotificationItem[]> {
    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(50);
    if (error) throw error;
    return (data as NotificationItem[]) ?? [];
  },

  async create(input: CreateNotificationInput): Promise<void> {
    const { error } = await supabase.from('notifications').insert({
      audience: input.audience ?? 'staff',
      category: input.category ?? 'general',
      title: input.title,
      body: input.body ?? null,
      link: input.link ?? null,
      read: false,
    });
    if (error) throw error;
  },

  async notifyContractExpiring(contractNumber: string, clientName: string, daysLeft: number, contractId: string): Promise<void> {
    await this.create({
      category: 'contract',
      title: daysLeft < 0 ? 'Contract expired without renewal' : `Contract expires in ${daysLeft} days`,
      body: `${contractNumber} · ${clientName}`,
      link: `/contracts/${contractId}`,
    });
  },

  async notifyVisitStarted(visitId: string, clientName: string): Promise<void> {
    await this.create({
      category: 'visit',
      title: 'Visit started',
      body: `Visit for ${clientName} has been started.`,
      link: `/visits/${visitId}`,
    });
  },

  async notifyVisitCompleted(visitId: string, clientName: string): Promise<void> {
    await this.create({
      category: 'visit',
      title: 'Visit completed',
      body: `Visit for ${clientName} has been completed and locked.`,
      link: `/visits/${visitId}`,
    });
  },

  async notifyScheduleConflict(clientName: string, date: string): Promise<void> {
    await this.create({
      category: 'schedule',
      title: 'Schedule conflict detected',
      body: `A scheduling conflict was found for ${clientName} on ${date}.`,
    });
  },

  async markRead(id: string): Promise<void> {
    const { error } = await supabase.from('notifications').update({ read: true }).eq('id', id);
    if (error) throw error;
  },

  async markAllRead(): Promise<void> {
    const { error } = await supabase.from('notifications').update({ read: true }).neq('read', true);
    if (error) throw error;
  },
};
