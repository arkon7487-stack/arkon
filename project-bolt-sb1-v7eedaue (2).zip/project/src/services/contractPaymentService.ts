import { supabase } from '@/lib/supabase';
import { ARKON_COMPANY_ID } from '@/lib/supabase';
import type { ContractPayment } from '@/types';

export interface RecordPaymentInput {
  contract_id: string;
  amount: number;
  payment_method?: string;
  payment_date?: string;
  notes?: string;
  recorded_by?: string;
}

export const contractPaymentService = {
  async record(input: RecordPaymentInput): Promise<ContractPayment> {
    if (input.amount <= 0) throw new Error('قيمة الدفعة يجب أن تكون أكبر من الصفر');

    // Fetch current contract state
    const { data: contract, error: cErr } = await supabase
      .from('contracts')
      .select('id, final_amount, amount_paid, remaining_balance, payment_status')
      .eq('id', input.contract_id)
      .maybeSingle();
    if (cErr) throw cErr;
    if (!contract) throw new Error('العقد غير موجود');

    const prevPaid = Number(contract.amount_paid ?? 0);
    const finalAmount = Number(contract.final_amount ?? 0);
    const newPaid = prevPaid + input.amount;
    const newRemaining = Math.max(0, finalAmount - newPaid);

    const paymentStatus =
      newRemaining === 0 ? 'fully_paid' :
      newPaid > 0 ? 'partially_paid' : 'unpaid';

    // Insert payment record
    const { data: payment, error: pErr } = await supabase
      .from('contract_payments')
      .insert({
        company_id: ARKON_COMPANY_ID,
        contract_id: input.contract_id,
        amount: input.amount,
        payment_method: input.payment_method || null,
        payment_date: input.payment_date ?? new Date().toISOString().slice(0, 10),
        notes: input.notes?.trim() || null,
        recorded_by: input.recorded_by || null,
      })
      .select('*')
      .maybeSingle();
    if (pErr) throw pErr;

    // Update contract financial totals
    const { error: uErr } = await supabase
      .from('contracts')
      .update({
        amount_paid: newPaid,
        remaining_balance: newRemaining,
        payment_status: paymentStatus,
        updated_at: new Date().toISOString(),
      })
      .eq('id', input.contract_id);
    if (uErr) throw uErr;

    return payment as ContractPayment;
  },

  async getForContract(contractId: string): Promise<ContractPayment[]> {
    const { data, error } = await supabase
      .from('contract_payments')
      .select('*')
      .eq('contract_id', contractId)
      .order('payment_date', { ascending: true });
    if (error) throw error;
    return (data as ContractPayment[]) ?? [];
  },

  async getReceivables(): Promise<Array<{
    contract_id: string;
    contract_number: string;
    client_name: string;
    final_amount: number;
    amount_paid: number;
    remaining_balance: number;
    payment_status: string;
    end_date: string;
  }>> {
    const { data, error } = await supabase
      .from('contracts')
      .select('id, contract_number, final_amount, amount_paid, remaining_balance, payment_status, end_date, client:clients(full_name)')
      .neq('payment_status', 'fully_paid')
      .in('status', ['active', 'draft'])
      .order('end_date', { ascending: true });
    if (error) throw error;
    return ((data ?? []) as Array<Record<string, unknown>>).map((r) => ({
      contract_id: r.id as string,
      contract_number: r.contract_number as string,
      client_name: ((r.client as Record<string, unknown>)?.full_name as string) ?? '—',
      final_amount: Number(r.final_amount ?? 0),
      amount_paid: Number(r.amount_paid ?? 0),
      remaining_balance: Number(r.remaining_balance ?? 0),
      payment_status: r.payment_status as string,
      end_date: r.end_date as string,
    }));
  },

  async getRevenueSummary(): Promise<{ collected: number; outstanding: number }> {
    const { data, error } = await supabase
      .from('contracts')
      .select('final_amount, amount_paid, remaining_balance, status')
      .in('status', ['active', 'draft', 'archived']);
    if (error) throw error;
    let collected = 0;
    let outstanding = 0;
    for (const c of (data ?? []) as Array<Record<string, unknown>>) {
      collected += Number(c.amount_paid ?? 0);
      outstanding += Number(c.remaining_balance ?? 0);
    }
    return { collected, outstanding };
  },
};
