import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
      { auth: { autoRefreshToken: false, persistSession: false } },
    );

    const body = (await req.json()) as { action: string; phone_number?: string; code?: string };
    const action = body.action;

    if (action === "request_otp") {
      if (!body.phone_number) return json({ error: "phone_number required" }, 400);
      const phone = body.phone_number.trim();

      const { data: client } = await supabase
        .from("clients")
        .select("id, full_name, phone_number")
        .eq("phone_number", phone)
        .maybeSingle();

      if (!client) return json({ error: "This phone number is not registered in ARKON." }, 404);

      const code = String(Math.floor(100000 + Math.random() * 900000));
      const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString();

      const { error } = await supabase.from("client_otps").insert({
        client_id: client.id,
        phone_number: phone,
        code_hash: await hash(code),
        expires_at: expiresAt,
      });
      if (error) return json({ error: "Could not issue OTP." }, 500);

      return json({ sent: true, demo_code: code }, 200);
    }

    if (action === "verify_otp") {
      if (!body.phone_number || !body.code) return json({ error: "phone_number and code required" }, 400);
      const phone = body.phone_number.trim();

      const { data: otps } = await supabase
        .from("client_otps")
        .select("id, code_hash, expires_at, consumed")
        .eq("phone_number", phone)
        .order("created_at", { ascending: false })
        .limit(1);

      const otp = otps?.[0];
      if (!otp) return json({ error: "No OTP found. Request a new code." }, 404);
      if (otp.consumed) return json({ error: "Code already used." }, 400);
      if (new Date(otp.expires_at).getTime() < Date.now())
        return json({ error: "Code expired." }, 400);

      const ok = (await hash(body.code)) === otp.code_hash;
      if (!ok) return json({ error: "Invalid code." }, 400);

      await supabase.from("client_otps").update({ consumed: true }).eq("id", otp.id);

      const { data: client } = await supabase
        .from("clients")
        .select("*")
        .eq("phone_number", phone)
        .maybeSingle();
      if (!client) return json({ error: "Client not found." }, 404);

      const token = crypto.randomUUID();
      const expiresAt = new Date(Date.now() + 12 * 60 * 60 * 1000).toISOString();
      await supabase.from("client_sessions").insert({
        client_id: client.id,
        token,
        expires_at: expiresAt,
      });

      return json({ client, token, expires_at: expiresAt }, 200);
    }

    return json({ error: "Unknown action. Use request_otp or verify_otp." }, 400);
  } catch (err) {
    return json({ error: (err as Error).message }, 500);
  }
});

async function hash(input: string): Promise<string> {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(input));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

function json(data: unknown, status: number) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
