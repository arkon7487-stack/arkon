import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const ADMIN_PASSWORD = "ARKON@2026";

const ACCOUNTS = [
  { email: "islam@gmail.com", name: "Islam Admin" },
  { email: "admin@arkon.enterprise", name: "System Admin" },
];

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
      { auth: { autoRefreshToken: false, persistSession: false } },
    );

    const { data: roleData } = await supabase
      .from("roles")
      .select("id")
      .eq("name", "Super Admin")
      .maybeSingle();

    if (!roleData) {
      return json({ error: "Super Admin role not found" }, 400);
    }

    const { data: existingUsers } = await supabase.auth.admin.listUsers();
    const results: Array<{ email: string; status: string; login_verified: boolean }> = [];

    for (const account of ACCOUNTS) {
      const existing = existingUsers?.users?.find((u) => u.email === account.email);
      let userId: string;

      if (existing) {
        const { data, error } = await supabase.auth.admin.updateUserById(existing.id, {
          password: ADMIN_PASSWORD,
          email_confirm: true,
          user_metadata: { full_name: account.name, source: "arkon_admin" },
        });
        if (error) {
          results.push({ email: account.email, status: `Update failed: ${error.message}`, login_verified: false });
          continue;
        }
        userId = data.user.id;
      } else {
        const { data, error } = await supabase.auth.admin.createUser({
          email: account.email,
          password: ADMIN_PASSWORD,
          email_confirm: true,
          user_metadata: { full_name: account.name, source: "arkon_admin" },
        });
        if (error) {
          results.push({ email: account.email, status: `Create failed: ${error.message}`, login_verified: false });
          continue;
        }
        userId = data.user.id;
      }

      await supabase
        .from("profiles")
        .upsert(
          { user_id: userId, role_id: roleData.id, employee_id: null, display_name: account.name },
          { onConflict: "user_id" },
        );

      const testClient = createClient(
        Deno.env.get("SUPABASE_URL")!,
        Deno.env.get("SUPABASE_ANON_KEY")!,
      );
      const { data: testData, error: testError } = await testClient.auth.signInWithPassword({
        email: account.email,
        password: ADMIN_PASSWORD,
      });

      results.push({
        email: account.email,
        status: testError ? `Login test failed: ${testError.message}` : "OK",
        login_verified: !testError && !!testData.user,
      });
    }

    return json({ success: true, accounts: results }, 200);
  } catch (err) {
    return json({ error: (err as Error).message }, 500);
  }
});

function json(data: unknown, status: number) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
